import { Router, Request, Response, NextFunction } from 'express';
import { loadDatabase, saveDatabase, hashPassword, StoredUser } from './db.ts';
import { Box, Floor, Room, DymoSettings, UserRole, HouseType, TaskCategory, MeterReading, MoveDayTask } from '../src/types/index.ts';

export const apiRouter = Router();

// Middleware to extract user from Authorization header
interface AuthenticatedRequest extends Request {
  currentUser?: {
    id: string;
    email?: string;
    role: UserRole;
    name: string;
  };
}

function authMiddleware(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    return next();
  }

  try {
    const token = authHeader.replace(/^Bearer\s+/i, '');
    if (token.startsWith('guest_')) {
      const parts = token.split(':');
      req.currentUser = {
        id: parts[0] || 'guest_user',
        name: decodeURIComponent(parts[1] || 'Verhuishulp (Gast)'),
        role: 'guest',
      };
      return next();
    }

    if (token.startsWith('admin_')) {
      const db = loadDatabase();
      const userId = token.replace('admin_', '');
      const user = db.users.find(u => u.id === userId && u.role === 'admin');
      if (user) {
        req.currentUser = {
          id: user.id,
          email: user.email,
          name: user.name,
          role: 'admin',
        };
      }
    }
  } catch (err) {
    console.warn('Auth token parse error:', err);
  }
  next();
}

function requireAdmin(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  if (!req.currentUser || req.currentUser.role !== 'admin') {
    return res.status(403).json({ error: 'Toegang geweigerd: Alleen beheerders (admins) hebben toegang tot deze actie.' });
  }
  next();
}

apiRouter.use(authMiddleware);

// --- Auth Endpoints ---

// Bootstrap info
apiRouter.get('/bootstrap', (_req: Request, res: Response) => {
  const db = loadDatabase();
  const hasAdmin = db.users.some(u => u.role === 'admin');
  res.json({
    isFirstRun: Boolean(db.isFirstRun),
    hasAdmin,
    defaultAdminEmail: 'admin@verhuizing.local',
  });
});

// Login: supports both email address AND username (e.g. 'admin')
apiRouter.post('/auth/login', (req: Request, res: Response) => {
  const { email, password, guestName, isGuest } = req.body;

  if (isGuest) {
    const cleanName = (guestName && typeof guestName === 'string' && guestName.trim()) 
      ? guestName.trim() 
      : 'Verhuishulp (Gast)';
    const guestId = `guest_${Date.now()}`;
    const token = `${guestId}:${encodeURIComponent(cleanName)}`;
    return res.json({
      token,
      user: {
        id: guestId,
        name: cleanName,
        email: 'gast@verhuizing.local',
        role: 'guest' as UserRole,
        createdAt: new Date().toISOString(),
      },
    });
  }

  // Admin login: check by email OR username (name)
  if (!email || !password) {
    return res.status(400).json({ error: 'Vul een gebruikersnaam/e-mailadres en wachtwoord in.' });
  }

  const db = loadDatabase();
  const identifier = String(email).trim().toLowerCase();

  const user = db.users.find(u => 
    u.email.toLowerCase() === identifier || 
    u.name.toLowerCase() === identifier ||
    (identifier === 'admin' && u.role === 'admin')
  );

  if (!user || user.passwordHash !== hashPassword(String(password))) {
    return res.status(401).json({ error: 'Ongeldige gebruikersnaam/e-mail of wachtwoord.' });
  }

  const token = `admin_${user.id}`;
  return res.json({
    token,
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      createdAt: user.createdAt,
    },
    isFirstRun: db.isFirstRun,
  });
});

// Dismiss first run banner
apiRouter.post('/auth/dismiss-first-run', requireAdmin, (_req: AuthenticatedRequest, res: Response) => {
  const db = loadDatabase();
  db.isFirstRun = false;
  saveDatabase(db);
  res.json({ success: true });
});

// Current user profile
apiRouter.get('/auth/me', (req: AuthenticatedRequest, res: Response) => {
  if (!req.currentUser) {
    return res.status(401).json({ error: 'Niet ingelogd' });
  }
  res.json({ user: req.currentUser });
});

// --- Main App State ---
apiRouter.get('/data', (_req: Request, res: Response) => {
  const db = loadDatabase();
  const safeUsers = db.users.map(({ passwordHash, ...rest }) => rest);
  res.json({
    users: safeUsers,
    floors: db.floors,
    rooms: db.rooms,
    boxes: db.boxes,
    settings: db.settings,
    meterReadings: db.meterReadings || [],
    moveDayTasks: db.moveDayTasks || [],
    isFirstRun: Boolean(db.isFirstRun),
  });
});

// --- Boxes API ---

// Create Box (Admin only)
apiRouter.post('/boxes', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const { title, items, fragile, targetRoomId, notes, currentRoomId, boxNumber } = req.body;
  const db = loadDatabase();

  if (!title || !targetRoomId) {
    return res.status(400).json({ error: 'Titel en doelruimte zijn verplicht.' });
  }

  let nextNum = 1;
  if (boxNumber && Number.isInteger(Number(boxNumber))) {
    nextNum = Number(boxNumber);
  } else if (db.boxes.length > 0) {
    const maxNum = Math.max(...db.boxes.map(b => b.boxNumber || 0));
    nextNum = maxNum + 1;
  }

  const paddedNum = String(nextNum).padStart(3, '0');
  const id = `BOX-${paddedNum}`;

  const defaultRoom = db.rooms.find(r => r.isDefaultFallback)?.id || db.rooms[0]?.id || targetRoomId;

  const newBox: Box = {
    id,
    boxNumber: nextNum,
    title: String(title).trim(),
    items: Array.isArray(items) ? items.filter(Boolean) : [],
    fragile: Boolean(fragile),
    targetRoomId: String(targetRoomId),
    currentRoomId: currentRoomId ? String(currentRoomId) : defaultRoom,
    status: 'IN_OLD_HOUSE',
    notes: notes ? String(notes).trim() : '',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  db.boxes.push(newBox);
  saveDatabase(db);

  res.status(201).json(newBox);
});

// Update Box
apiRouter.put('/boxes/:id', (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const db = loadDatabase();
  const boxIndex = db.boxes.findIndex(b => b.id.toLowerCase() === id.toLowerCase());

  if (boxIndex === -1) {
    return res.status(404).json({ error: 'Doos niet gevonden.' });
  }

  const existing = db.boxes[boxIndex];
  const isGuest = !req.currentUser || req.currentUser.role === 'guest';

  const garageRoom = db.rooms.find(r => r.isDefaultFallback) || db.rooms.find(r => r.name.toLowerCase().includes('garage')) || db.rooms[0];
  const garageId = garageRoom?.id || existing.currentRoomId;

  if (isGuest) {
    const { status, currentRoomId } = req.body;
    let newStatus = existing.status;
    let newLocation = existing.currentRoomId;

    if (status && ['IN_OLD_HOUSE', 'IN_TRANSIT', 'MOVED'].includes(status)) {
      newStatus = status;
    }

    if (newStatus === 'MOVED') {
      if (!currentRoomId || currentRoomId === '') {
        newLocation = garageId;
      } else {
        newLocation = currentRoomId;
      }
    } else if (currentRoomId) {
      newLocation = currentRoomId;
    }

    db.boxes[boxIndex] = {
      ...existing,
      status: newStatus,
      currentRoomId: newLocation,
      updatedAt: new Date().toISOString(),
    };
  } else {
    const { title, items, fragile, targetRoomId, currentRoomId, status, notes, boxNumber } = req.body;

    let targetLocation = currentRoomId !== undefined ? currentRoomId : existing.currentRoomId;
    const newStatus = status || existing.status;

    if (newStatus === 'MOVED' && (!targetLocation || targetLocation === '')) {
      targetLocation = garageId;
    }

    db.boxes[boxIndex] = {
      ...existing,
      title: title !== undefined ? String(title).trim() : existing.title,
      items: Array.isArray(items) ? items.filter(Boolean) : existing.items,
      fragile: fragile !== undefined ? Boolean(fragile) : existing.fragile,
      targetRoomId: targetRoomId !== undefined ? String(targetRoomId) : existing.targetRoomId,
      currentRoomId: targetLocation,
      status: newStatus,
      notes: notes !== undefined ? String(notes).trim() : existing.notes,
      boxNumber: boxNumber !== undefined ? Number(boxNumber) : existing.boxNumber,
      updatedAt: new Date().toISOString(),
    };
  }

  saveDatabase(db);
  res.json(db.boxes[boxIndex]);
});

// Delete Box
apiRouter.delete('/boxes/:id', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const db = loadDatabase();
  const initialLength = db.boxes.length;
  db.boxes = db.boxes.filter(b => b.id.toLowerCase() !== id.toLowerCase());

  if (db.boxes.length === initialLength) {
    return res.status(404).json({ error: 'Doos niet gevonden.' });
  }

  saveDatabase(db);
  res.json({ success: true, id });
});

// --- Hierarchical Location Management (Floors & Rooms) ---

// Floors
apiRouter.post('/floors', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const { name, houseType } = req.body;
  if (!name) return res.status(400).json({ error: 'Verdiepingnaam is verplicht.' });

  const db = loadDatabase();
  const id = `floor_${houseType === 'OLD' ? 'old_' : 'new_'}${Date.now()}`;
  const newFloor: Floor = {
    id,
    name: String(name).trim(),
    houseType: houseType === 'OLD' ? 'OLD' : 'NEW',
    orderIndex: db.floors.length,
  };
  db.floors.push(newFloor);
  saveDatabase(db);
  res.status(201).json(newFloor);
});

apiRouter.put('/floors/:id', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const { name, houseType } = req.body;
  const db = loadDatabase();
  const floor = db.floors.find(f => f.id === id);
  if (!floor) return res.status(404).json({ error: 'Verdieping niet gevonden.' });

  if (name) floor.name = String(name).trim();
  if (houseType) floor.houseType = houseType === 'OLD' ? 'OLD' : 'NEW';
  saveDatabase(db);
  res.json(floor);
});

apiRouter.delete('/floors/:id', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const db = loadDatabase();

  const roomsInFloor = db.rooms.filter(r => r.floorId === id);
  if (roomsInFloor.length > 0) {
    return res.status(400).json({ error: `Kan verdieping niet verwijderen: bevat nog ${roomsInFloor.length} kamer(s). Verplaats of verwijder eerst de kamers.` });
  }

  db.floors = db.floors.filter(f => f.id !== id);
  saveDatabase(db);
  res.json({ success: true });
});

// Rooms
apiRouter.post('/rooms', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const { name, floorId, isDefaultFallback, houseType } = req.body;
  if (!name || !floorId) {
    return res.status(400).json({ error: 'Kamernaam en verdieping zijn verplicht.' });
  }

  const db = loadDatabase();
  const targetHouse = houseType === 'OLD' ? 'OLD' : 'NEW';

  if (isDefaultFallback && targetHouse === 'NEW') {
    db.rooms.forEach(r => {
      if (r.houseType === 'NEW') r.isDefaultFallback = false;
    });
  }

  const id = `room_${targetHouse === 'OLD' ? 'old_' : 'new_'}${Date.now()}`;
  const newRoom: Room = {
    id,
    floorId: String(floorId),
    name: String(name).trim(),
    houseType: targetHouse,
    isDefaultFallback: Boolean(isDefaultFallback && targetHouse === 'NEW'),
    isReadyForMove: false,
    tasks: [],
    orderIndex: db.rooms.length,
  };

  db.rooms.push(newRoom);
  saveDatabase(db);
  res.status(201).json(newRoom);
});

apiRouter.put('/rooms/:id', (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const { name, floorId, isDefaultFallback, houseType, isReadyForMove } = req.body;
  const db = loadDatabase();
  const room = db.rooms.find(r => r.id === id);
  if (!room) return res.status(404).json({ error: 'Kamer niet gevonden.' });

  // Helpers and admins can toggle isReadyForMove
  if (isReadyForMove !== undefined) {
    room.isReadyForMove = Boolean(isReadyForMove);
  }

  // Admin-only updates for name, floor, etc.
  if (req.currentUser?.role === 'admin') {
    if (name) room.name = String(name).trim();
    if (floorId) room.floorId = String(floorId);
    if (houseType) room.houseType = houseType === 'OLD' ? 'OLD' : 'NEW';

    if (isDefaultFallback !== undefined) {
      if (isDefaultFallback && room.houseType === 'NEW') {
        db.rooms.forEach(r => { if (r.houseType === 'NEW') r.isDefaultFallback = false; });
        room.isDefaultFallback = true;
      } else {
        room.isDefaultFallback = false;
      }
    }
  }

  saveDatabase(db);
  res.json(room);
});

apiRouter.delete('/rooms/:id', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const db = loadDatabase();

  const boxesInRoom = db.boxes.filter(b => b.targetRoomId === id || b.currentRoomId === id);
  if (boxesInRoom.length > 0) {
    return res.status(400).json({ error: `Kan kamer niet verwijderen: ${boxesInRoom.length} doos/dozen hebben deze kamer als doel of huidige locatie.` });
  }

  const room = db.rooms.find(r => r.id === id);
  if (room?.isDefaultFallback) {
    return res.status(400).json({ error: 'Kan de standaard fallback locatie (Garage) niet verwijderen. Wijs eerst een andere kamer aan als fallback.' });
  }

  db.rooms = db.rooms.filter(r => r.id !== id);
  saveDatabase(db);
  res.json({ success: true });
});

// --- Room Tasks API ---

// Add task to room
apiRouter.post('/rooms/:id/tasks', (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const { text, category } = req.body;
  if (!text || !String(text).trim()) {
    return res.status(400).json({ error: 'Taakomschrijving is verplicht.' });
  }

  const db = loadDatabase();
  const room = db.rooms.find(r => r.id === id);
  if (!room) return res.status(404).json({ error: 'Kamer niet gevonden.' });

  if (!room.tasks) room.tasks = [];

  const newTask = {
    id: `task_${Date.now()}`,
    text: String(text).trim(),
    completed: false,
    category: (['INPAKKEN', 'POETSEN', 'KLUSSEN', 'OVERIG'].includes(category) ? category : 'OVERIG') as TaskCategory,
    createdAt: new Date().toISOString(),
  };

  room.tasks.push(newTask);
  saveDatabase(db);
  res.status(201).json(newTask);
});

// Update / Toggle task in room
apiRouter.put('/rooms/:id/tasks/:taskId', (req: AuthenticatedRequest, res: Response) => {
  const { id, taskId } = req.params;
  const { completed, text, category } = req.body;
  const db = loadDatabase();
  const room = db.rooms.find(r => r.id === id);
  if (!room || !room.tasks) return res.status(404).json({ error: 'Kamer of taken niet gevonden.' });

  const task = room.tasks.find(t => t.id === taskId);
  if (!task) return res.status(404).json({ error: 'Taak niet gevonden.' });

  if (completed !== undefined) task.completed = Boolean(completed);
  if (text !== undefined) task.text = String(text).trim();
  if (category && ['INPAKKEN', 'POETSEN', 'KLUSSEN', 'OVERIG'].includes(category)) {
    task.category = category as TaskCategory;
  }

  saveDatabase(db);
  res.json(task);
});

// Delete task from room
apiRouter.delete('/rooms/:id/tasks/:taskId', (req: AuthenticatedRequest, res: Response) => {
  const { id, taskId } = req.params;
  const db = loadDatabase();
  const room = db.rooms.find(r => r.id === id);
  if (!room || !room.tasks) return res.status(404).json({ error: 'Kamer niet gevonden.' });

  room.tasks = room.tasks.filter(t => t.id !== taskId);
  saveDatabase(db);
  res.json({ success: true });
});

// --- Meter Readings API ---
apiRouter.post('/meter-readings', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const { houseType, type, name, reading, unit, date, notes } = req.body;
  const db = loadDatabase();

  const newReading: MeterReading = {
    id: `m_${houseType === 'OLD' ? 'old_' : 'new_'}${Date.now()}`,
    houseType: houseType === 'OLD' ? 'OLD' : 'NEW',
    type: type || 'WATER',
    name: name || 'Meter',
    reading: reading || '',
    unit: unit || '',
    date: date || new Date().toISOString().slice(0, 10),
    notes: notes || '',
  };

  db.meterReadings = db.meterReadings || [];
  db.meterReadings.push(newReading);
  saveDatabase(db);
  res.status(201).json(newReading);
});

apiRouter.put('/meter-readings/:id', (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const { reading, date, notes, name } = req.body;
  const db = loadDatabase();

  db.meterReadings = db.meterReadings || [];
  const item = db.meterReadings.find(m => m.id === id);
  if (!item) return res.status(404).json({ error: 'Meterstand niet gevonden.' });

  if (reading !== undefined) item.reading = String(reading);
  if (date !== undefined) item.date = String(date);
  if (notes !== undefined) item.notes = String(notes);
  if (name !== undefined) item.name = String(name);

  saveDatabase(db);
  res.json(item);
});

// --- Move Day Tasks / Timeline API ---
apiRouter.post('/move-day-tasks', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const { time, title, description, assignedTo } = req.body;
  if (!title) return res.status(400).json({ error: 'Titel is verplicht.' });

  const db = loadDatabase();
  const newTask: MoveDayTask = {
    id: `md_${Date.now()}`,
    time: time || '09:00',
    title: String(title).trim(),
    description: description ? String(description).trim() : '',
    assignedTo: assignedTo ? String(assignedTo).trim() : '',
    completed: false,
  };

  db.moveDayTasks = db.moveDayTasks || [];
  db.moveDayTasks.push(newTask);
  saveDatabase(db);
  res.status(201).json(newTask);
});

apiRouter.put('/move-day-tasks/:id', (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const { completed, time, title, description, assignedTo } = req.body;
  const db = loadDatabase();

  db.moveDayTasks = db.moveDayTasks || [];
  const task = db.moveDayTasks.find(t => t.id === id);
  if (!task) return res.status(404).json({ error: 'Draaiboek-taak niet gevonden.' });

  if (completed !== undefined) task.completed = Boolean(completed);
  if (time !== undefined) task.time = String(time);
  if (title !== undefined) task.title = String(title).trim();
  if (description !== undefined) task.description = String(description).trim();
  if (assignedTo !== undefined) task.assignedTo = String(assignedTo).trim();

  saveDatabase(db);
  res.json(task);
});

apiRouter.delete('/move-day-tasks/:id', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const db = loadDatabase();
  db.moveDayTasks = (db.moveDayTasks || []).filter(t => t.id !== id);
  saveDatabase(db);
  res.json({ success: true });
});

// --- User Management (Admin only) ---
apiRouter.get('/users', requireAdmin, (_req: AuthenticatedRequest, res: Response) => {
  const db = loadDatabase();
  const safeUsers = db.users.map(({ passwordHash, ...rest }) => rest);
  res.json(safeUsers);
});

apiRouter.post('/users', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const { name, email, password, role } = req.body;
  if (!name || !email) {
    return res.status(400).json({ error: 'Naam en e-mailadres zijn verplicht.' });
  }

  const db = loadDatabase();
  const normalizedEmail = String(email).trim().toLowerCase();
  if (db.users.some(u => u.email.toLowerCase() === normalizedEmail)) {
    return res.status(400).json({ error: 'Er bestaat al een gebruiker met dit e-mailadres.' });
  }

  const newUser: StoredUser = {
    id: `user_${Date.now()}`,
    name: String(name).trim(),
    email: normalizedEmail,
    role: (role === 'admin' ? 'admin' : 'guest') as UserRole,
    passwordHash: password ? hashPassword(String(password)) : undefined,
    createdAt: new Date().toISOString(),
  };

  db.users.push(newUser);
  saveDatabase(db);

  const { passwordHash, ...safe } = newUser;
  res.status(201).json(safe);
});

apiRouter.put('/users/:id', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const { name, email, password, role } = req.body;
  const db = loadDatabase();
  const user = db.users.find(u => u.id === id);
  if (!user) return res.status(404).json({ error: 'Gebruiker niet gevonden.' });

  if (name) user.name = String(name).trim();
  if (email) user.email = String(email).trim().toLowerCase();
  if (role && ['admin', 'guest'].includes(role)) {
    if (user.role === 'admin' && role === 'guest') {
      const adminCount = db.users.filter(u => u.role === 'admin').length;
      if (adminCount <= 1) {
        return res.status(400).json({ error: 'Kan de enige admin niet degraderen naar gast.' });
      }
    }
    user.role = role;
  }
  if (password) {
    user.passwordHash = hashPassword(String(password));
  }

  saveDatabase(db);
  const { passwordHash, ...safe } = user;
  res.json(safe);
});

apiRouter.delete('/users/:id', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const db = loadDatabase();

  const user = db.users.find(u => u.id === id);
  if (!user) return res.status(404).json({ error: 'Gebruiker niet gevonden.' });

  if (user.role === 'admin') {
    const adminCount = db.users.filter(u => u.role === 'admin').length;
    if (adminCount <= 1) {
      return res.status(400).json({ error: 'Kan de laatste beheerder (admin) niet verwijderen.' });
    }
  }

  db.users = db.users.filter(u => u.id !== id);
  saveDatabase(db);
  res.json({ success: true });
});

// --- Dymo Settings (Admin only) ---
apiRouter.post('/settings', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const { widthMm, heightMm, name, fontSizeScale, showContents, showFloor } = req.body;
  const db = loadDatabase();

  db.settings = {
    widthMm: Number(widthMm) || 89,
    heightMm: Number(heightMm) || 41,
    name: name ? String(name) : `${Number(widthMm)} x ${Number(heightMm)} mm`,
    fontSizeScale: Number(fontSizeScale) || 1.0,
    showContents: showContents !== undefined ? Boolean(showContents) : true,
    showFloor: showFloor !== undefined ? Boolean(showFloor) : true,
  };

  saveDatabase(db);
  res.json(db.settings);
});
