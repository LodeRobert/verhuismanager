import React, { useState, useEffect, useCallback } from 'react';
import {
  Package,
  Layers,
  MapPin,
  Users,
  Printer,
  Camera,
  AlertCircle,
  CheckCircle2,
  Info,
  X,
} from 'lucide-react';
import { api, getStoredUser, clearSession } from './services/api.ts';
import { AppState, Box, Floor, Room, User, DymoSettings, BoxStatus, TaskCategory, MeterReading, MoveDayTask } from './types/index.ts';
import { Navbar } from './components/Navbar.tsx';
import { LoginView } from './components/LoginView.tsx';
import { DashboardView } from './components/DashboardView.tsx';
import { RoomsOverviewView } from './components/RoomsOverviewView.tsx';
import { BoxDetailModal } from './components/BoxDetailModal.tsx';
import { BoxFormModal } from './components/BoxFormModal.tsx';
import { DymoPrintModal } from './components/DymoPrintModal.tsx';
import { LocationManagerModal } from './components/LocationManagerModal.tsx';
import { UserManagerModal } from './components/UserManagerModal.tsx';
import { ScannerModal } from './components/ScannerModal.tsx';
import { RoomTasksModal } from './components/RoomTasksModal.tsx';
import { MeterReadingsModal } from './components/MeterReadingsModal.tsx';
import { MoveDayTimelineModal } from './components/MoveDayTimelineModal.tsx';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(getStoredUser());
  const [appData, setAppData] = useState<AppState | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'rooms'>('dashboard');
  const [errorToast, setErrorToast] = useState<string | null>(null);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  // Modals
  const [selectedBox, setSelectedBox] = useState<Box | null>(null);
  const [editingBox, setEditingBox] = useState<Box | null>(null);
  const [isAddingBox, setIsAddingBox] = useState(false);
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [boxesToPrint, setBoxesToPrint] = useState<Box[]>([]);
  const [isLocationManagerOpen, setIsLocationManagerOpen] = useState(false);
  const [isUserManagerOpen, setIsUserManagerOpen] = useState(false);
  const [selectedRoomForTasks, setSelectedRoomForTasks] = useState<Room | null>(null);
  const [isMeterReadingsOpen, setIsMeterReadingsOpen] = useState(false);
  const [isMoveDayTimelineOpen, setIsMoveDayTimelineOpen] = useState(false);

  const showToast = (message: string, isError = false) => {
    if (isError) {
      setErrorToast(message);
      setTimeout(() => setErrorToast(null), 5000);
    } else {
      setSuccessToast(message);
      setTimeout(() => setErrorToast(null), 3500);
    }
  };

  const loadData = useCallback(async () => {
    try {
      setLoading(true);
      const data = await api.getAppData();
      setAppData(data);
    } catch (err: unknown) {
      console.error('Fout bij ophalen van data:', err);
      if (err instanceof Error && err.message.includes('401')) {
        clearSession();
        setCurrentUser(null);
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData, currentUser]);

  // Handle URL hash changes (e.g. from smartphone scanning the Dymo QR code: /#box=BOX-002)
  useEffect(() => {
    const handleHash = () => {
      const hash = window.location.hash;
      if (hash && hash.includes('box=') && appData?.boxes) {
        const boxId = hash.split('box=')[1];
        const found = appData.boxes.find(
          (b) => b.id.toLowerCase() === boxId.toLowerCase() || String(b.boxNumber) === boxId
        );
        if (found) {
          setSelectedBox(found);
        }
      }
    };

    handleHash();
    window.addEventListener('hashchange', handleHash);
    return () => window.removeEventListener('hashchange', handleHash);
  }, [appData]);

  const handleLogout = () => {
    clearSession();
    setCurrentUser(null);
    setAppData(null);
    showToast('U bent uitgelogd.');
  };

  // --- Box Handlers ---
  const handleUpdateBoxStatus = async (boxId: string, status: BoxStatus, currentRoomId?: string) => {
    try {
      const updated = await api.updateBox(boxId, { status, currentRoomId });
      setAppData((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          boxes: prev.boxes.map((b) => (b.id === updated.id ? updated : b)),
        };
      });
      setSelectedBox(updated);
      showToast(`Status van doos #${updated.boxNumber} succesvol bijgewerkt.`);
    } catch (err: unknown) {
      if (err instanceof Error) showToast(err.message, true);
    }
  };

  const handleSaveBox = async (boxData: Partial<Box>) => {
    try {
      if (editingBox) {
        const updated = await api.updateBox(editingBox.id, boxData);
        setAppData((prev) => {
          if (!prev) return null;
          return {
            ...prev,
            boxes: prev.boxes.map((b) => (b.id === updated.id ? updated : b)),
          };
        });
        showToast(`Doos #${updated.boxNumber} gewijzigd.`);
      } else {
        const created = await api.createBox(boxData);
        setAppData((prev) => {
          if (!prev) return null;
          return {
            ...prev,
            boxes: [created, ...prev.boxes],
          };
        });
        showToast(`Doos #${created.boxNumber} (${created.id}) aangemaakt!`);
      }
      setEditingBox(null);
      setIsAddingBox(false);
    } catch (err: unknown) {
      if (err instanceof Error) showToast(err.message, true);
      throw err;
    }
  };

  const handleDeleteBox = async (boxId: string) => {
    try {
      await api.deleteBox(boxId);
      setAppData((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          boxes: prev.boxes.filter((b) => b.id !== boxId),
        };
      });
      setSelectedBox(null);
      showToast('Doos succesvol verwijderd.');
    } catch (err: unknown) {
      if (err instanceof Error) showToast(err.message, true);
    }
  };

  // --- Location Handlers ---
  const handleCreateFloor = async (name: string) => {
    const created = await api.createFloor(name);
    setAppData((prev) => (prev ? { ...prev, floors: [...prev.floors, created] } : null));
    showToast(`Verdieping "${created.name}" toegevoegd.`);
  };

  const handleUpdateFloor = async (id: string, name: string) => {
    const updated = await api.updateFloor(id, name);
    setAppData((prev) =>
      prev ? { ...prev, floors: prev.floors.map((f) => (f.id === id ? updated : f)) } : null
    );
    showToast('Verdieping aangepast.');
  };

  const handleDeleteFloor = async (id: string) => {
    await api.deleteFloor(id);
    setAppData((prev) => (prev ? { ...prev, floors: prev.floors.filter((f) => f.id !== id) } : null));
    showToast('Verdieping verwijderd.');
  };

  const handleCreateRoom = async (roomData: { name: string; floorId: string; isDefaultFallback?: boolean }) => {
    const created = await api.createRoom(roomData);
    setAppData((prev) => {
      if (!prev) return null;
      let rooms = [...prev.rooms];
      if (created.isDefaultFallback) {
        rooms = rooms.map((r) => ({ ...r, isDefaultFallback: r.id === created.id }));
      }
      return { ...prev, rooms: [...rooms, created] };
    });
    showToast(`Kamer "${created.name}" toegevoegd.`);
  };

  const handleUpdateRoom = async (id: string, roomData: { name?: string; floorId?: string; isDefaultFallback?: boolean }) => {
    const updated = await api.updateRoom(id, roomData);
    setAppData((prev) => {
      if (!prev) return null;
      let rooms = prev.rooms.map((r) => (r.id === id ? updated : r));
      if (updated.isDefaultFallback) {
        rooms = rooms.map((r) => ({ ...r, isDefaultFallback: r.id === id }));
      }
      return { ...prev, rooms };
    });
    showToast('Kamer aangepast.');
  };

  const handleDeleteRoom = async (id: string) => {
    await api.deleteRoom(id);
    setAppData((prev) => (prev ? { ...prev, rooms: prev.rooms.filter((r) => r.id !== id) } : null));
    showToast('Kamer verwijderd.');
  };

  // --- User Handlers ---
  const handleCreateUser = async (userData: { name: string; email: string; password?: string; role: 'admin' | 'guest' }) => {
    const created = await api.createUser(userData);
    setAppData((prev) => (prev ? { ...prev, users: [...prev.users, created] } : null));
    showToast(`Gebruiker "${created.name}" aangemaakt.`);
  };

  const handleUpdateUser = async (id: string, userData: { name?: string; email?: string; password?: string; role?: 'admin' | 'guest' }) => {
    const updated = await api.updateUser(id, userData);
    setAppData((prev) =>
      prev ? { ...prev, users: prev.users.map((u) => (u.id === id ? updated : u)) } : null
    );
    showToast('Gebruiker aangepast.');
  };

  const handleDeleteUser = async (id: string) => {
    await api.deleteUser(id);
    setAppData((prev) => (prev ? { ...prev, users: prev.users.filter((u) => u.id !== id) } : null));
    showToast('Gebruiker verwijderd.');
  };

  // --- Dymo Settings ---
  const handleSaveSettings = async (settings: DymoSettings) => {
    try {
      const updated = await api.updateSettings(settings);
      setAppData((prev) => (prev ? { ...prev, settings: updated } : null));
      showToast('Dymo label instellingen opgeslagen.');
    } catch (err: unknown) {
      if (err instanceof Error) showToast(err.message, true);
    }
  };

  // --- Room Tasks & Readiness Handlers ---
  const handleToggleRoomReadiness = async (roomId: string, isReady: boolean) => {
    try {
      const updated = await api.toggleRoomReadiness(roomId, isReady);
      setAppData((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          rooms: prev.rooms.map((r) => (r.id === roomId ? updated : r)),
        };
      });
      if (selectedRoomForTasks?.id === roomId) {
        setSelectedRoomForTasks(updated);
      }
      showToast(
        isReady
          ? `Kamer "${updated.name}" is verhuisklaar gemarkeerd! 🎉`
          : `Kamer "${updated.name}" staat weer open voor werk.`
      );
    } catch (err: unknown) {
      if (err instanceof Error) showToast(err.message, true);
    }
  };

  const handleAddTask = async (roomId: string, task: { text: string; category: TaskCategory }) => {
    try {
      const createdTask = await api.addRoomTask(roomId, task);
      setAppData((prev) => {
        if (!prev) return null;
        const updatedRooms = prev.rooms.map((r) => {
          if (r.id === roomId) {
            const tasks = [...(r.tasks || []), createdTask];
            return { ...r, tasks };
          }
          return r;
        });
        return { ...prev, rooms: updatedRooms };
      });
      setSelectedRoomForTasks((prev) => {
        if (!prev || prev.id !== roomId) return prev;
        return { ...prev, tasks: [...(prev.tasks || []), createdTask] };
      });
      showToast('Werkpunt toegevoegd.');
    } catch (err: unknown) {
      if (err instanceof Error) showToast(err.message, true);
    }
  };

  const handleToggleTask = async (roomId: string, taskId: string, completed: boolean) => {
    try {
      const updatedTask = await api.updateRoomTask(roomId, taskId, { completed });
      setAppData((prev) => {
        if (!prev) return null;
        const updatedRooms = prev.rooms.map((r) => {
          if (r.id === roomId) {
            const tasks = (r.tasks || []).map((t) => (t.id === taskId ? updatedTask : t));
            return { ...r, tasks };
          }
          return r;
        });
        return { ...prev, rooms: updatedRooms };
      });
      setSelectedRoomForTasks((prev) => {
        if (!prev || prev.id !== roomId) return prev;
        return {
          ...prev,
          tasks: (prev.tasks || []).map((t) => (t.id === taskId ? updatedTask : t)),
        };
      });
    } catch (err: unknown) {
      if (err instanceof Error) showToast(err.message, true);
    }
  };

  const handleDeleteTask = async (roomId: string, taskId: string) => {
    try {
      await api.deleteRoomTask(roomId, taskId);
      setAppData((prev) => {
        if (!prev) return null;
        const updatedRooms = prev.rooms.map((r) => {
          if (r.id === roomId) {
            return { ...r, tasks: (r.tasks || []).filter((t) => t.id !== taskId) };
          }
          return r;
        });
        return { ...prev, rooms: updatedRooms };
      });
      setSelectedRoomForTasks((prev) => {
        if (!prev || prev.id !== roomId) return prev;
        return { ...prev, tasks: (prev.tasks || []).filter((t) => t.id !== taskId) };
      });
      showToast('Werkpunt verwijderd.');
    } catch (err: unknown) {
      if (err instanceof Error) showToast(err.message, true);
    }
  };

  // --- Meter Readings Handlers ---
  const handleSaveMeterReading = async (id: string, data: Partial<MeterReading>) => {
    try {
      const updated = await api.updateMeterReading(id, data);
      setAppData((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          meterReadings: (prev.meterReadings || []).map((m) => (m.id === id ? updated : m)),
        };
      });
      showToast('Meterstand succesvol opgeslagen.');
    } catch (err: unknown) {
      if (err instanceof Error) showToast(err.message, true);
      throw err;
    }
  };

  // --- Move Day Timeline Handlers ---
  const handleToggleMoveDayTask = async (id: string, completed: boolean) => {
    try {
      const updated = await api.updateMoveDayTask(id, { completed });
      setAppData((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          moveDayTasks: (prev.moveDayTasks || []).map((t) => (t.id === id ? updated : t)),
        };
      });
    } catch (err: unknown) {
      if (err instanceof Error) showToast(err.message, true);
    }
  };

  const handleAddMoveDayTask = async (task: Partial<MoveDayTask>) => {
    try {
      const created = await api.createMoveDayTask(task);
      setAppData((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          moveDayTasks: [...(prev.moveDayTasks || []), created],
        };
      });
      showToast('Draaiboek taak toegevoegd.');
    } catch (err: unknown) {
      if (err instanceof Error) showToast(err.message, true);
    }
  };

  const handleDeleteMoveDayTask = async (id: string) => {
    try {
      await api.deleteMoveDayTask(id);
      setAppData((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          moveDayTasks: (prev.moveDayTasks || []).filter((t) => t.id !== id),
        };
      });
      showToast('Taak verwijderd uit draaiboek.');
    } catch (err: unknown) {
      if (err instanceof Error) showToast(err.message, true);
    }
  };

  const handleDismissFirstRun = async () => {
    try {
      await api.dismissFirstRun();
      setAppData((prev) => (prev ? { ...prev, isFirstRun: false } : null));
    } catch {
      // ignore
    }
  };

  // If user is not logged in, show Startscherm / LoginView
  if (!currentUser) {
    return (
      <LoginView
        onLoginSuccess={(user) => {
          setCurrentUser(user);
          showToast(`Welkom, ${user.name}!`);
        }}
        isFirstRun={Boolean(appData?.isFirstRun)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col selection:bg-blue-100 selection:text-blue-900">
      {/* Top Navbar & Mobile Bottom Tab Bar */}
      <Navbar
        currentUser={currentUser}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenScanner={() => setIsScannerOpen(true)}
        onOpenPrintModal={() => {
          setBoxesToPrint(appData?.boxes || []);
          setIsPrintModalOpen(true);
        }}
        onOpenLocationManager={() => setIsLocationManagerOpen(true)}
        onOpenUserManager={() => setIsUserManagerOpen(true)}
        onOpenMeterReadings={() => setIsMeterReadingsOpen(true)}
        onOpenMoveDayTimeline={() => setIsMoveDayTimelineOpen(true)}
        onAddNewBox={() => {
          setEditingBox(null);
          setIsAddingBox(true);
        }}
        onLogout={handleLogout}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-24 md:pb-12">
        {/* First Run Admin Banner (if logged in as initial admin) */}
        {appData?.isFirstRun && currentUser.role === 'admin' && (
          <div className="mb-6 p-4 rounded-2xl bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 text-blue-900 dark:text-blue-200 flex items-start justify-between shadow-xs">
            <div className="flex items-start gap-3">
              <Info className="w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-bold text-blue-950 dark:text-white">
                  Eerste opstart: VerhuisManager is gereed!
                </h4>
                <p className="text-xs text-blue-800 dark:text-blue-300 mt-1 leading-relaxed">
                  U bent ingelogd als standaardbeheerder (<span className="font-mono font-semibold">admin@verhuizing.local</span>). U kunt in 'Gebruikers' uw wachtwoord aanpassen en helpers toevoegen.
                </p>
              </div>
            </div>
            <button
              onClick={handleDismissFirstRun}
              className="text-blue-500 hover:text-blue-800 dark:hover:text-blue-200 p-1 rounded-lg"
              title="Melding sluiten"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Views */}
        {appData && (
          <>
            {activeTab === 'dashboard' ? (
              <DashboardView
                boxes={appData.boxes}
                rooms={appData.rooms}
                floors={appData.floors}
                userRole={currentUser.role}
                onSelectBox={(box) => setSelectedBox(box)}
                onAddNewBox={() => {
                  setEditingBox(null);
                  setIsAddingBox(true);
                }}
                onOpenPrintModal={(filtered) => {
                  setBoxesToPrint(filtered || appData.boxes);
                  setIsPrintModalOpen(true);
                }}
                onQuickUpdateStatus={async (id, status) => {
                  await handleUpdateBoxStatus(id, status);
                }}
              />
            ) : (
              <RoomsOverviewView
                rooms={appData.rooms}
                floors={appData.floors}
                boxes={appData.boxes}
                userRole={currentUser.role}
                onSelectBox={(box) => setSelectedBox(box)}
                onOpenLocationManager={() => setIsLocationManagerOpen(true)}
                onOpenRoomTasks={(room) => setSelectedRoomForTasks(room)}
                onToggleRoomReadiness={handleToggleRoomReadiness}
              />
            )}
          </>
        )}
      </main>

      {/* Floating Action Toasts */}
      {errorToast && (
        <div className="fixed bottom-20 md:bottom-6 right-4 z-50 p-4 bg-red-600 text-white text-xs font-semibold rounded-2xl shadow-xl flex items-center gap-2.5 animate-bounce">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorToast}</span>
          <button onClick={() => setErrorToast(null)} className="ml-2 text-white/80 hover:text-white">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {successToast && (
        <div className="fixed bottom-20 md:bottom-6 right-4 z-50 p-3.5 bg-emerald-600 text-white text-xs font-semibold rounded-2xl shadow-xl flex items-center gap-2.5">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{successToast}</span>
          <button onClick={() => setSuccessToast(null)} className="ml-2 text-white/80 hover:text-white">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Modals */}
      {selectedBox && appData && (
        <BoxDetailModal
          box={selectedBox}
          rooms={appData.rooms}
          floors={appData.floors}
          userRole={currentUser.role}
          onUpdateStatus={handleUpdateBoxStatus}
          onEditBox={(b) => {
            setSelectedBox(null);
            setEditingBox(b);
          }}
          onDeleteBox={handleDeleteBox}
          onPrintLabel={(b) => {
            setBoxesToPrint([b]);
            setIsPrintModalOpen(true);
          }}
          onClose={() => setSelectedBox(null)}
        />
      )}

      {(isAddingBox || editingBox) && appData && (
        <BoxFormModal
          initialBox={editingBox}
          rooms={appData.rooms}
          floors={appData.floors}
          existingBoxesCount={appData.boxes.length}
          onSave={handleSaveBox}
          onClose={() => {
            setIsAddingBox(false);
            setEditingBox(null);
          }}
        />
      )}

      {isPrintModalOpen && appData && (
        <DymoPrintModal
          boxes={boxesToPrint.length > 0 ? boxesToPrint : appData.boxes}
          rooms={appData.rooms}
          floors={appData.floors}
          settings={appData.settings}
          onSaveSettings={handleSaveSettings}
          onClose={() => setIsPrintModalOpen(false)}
        />
      )}

      {isScannerOpen && appData && (
        <ScannerModal
          boxes={appData.boxes}
          onSelectBox={(box) => {
            setIsScannerOpen(false);
            setSelectedBox(box);
          }}
          onClose={() => setIsScannerOpen(false)}
        />
      )}

      {isLocationManagerOpen && appData && (
        <LocationManagerModal
          floors={appData.floors}
          rooms={appData.rooms}
          onCreateFloor={handleCreateFloor}
          onUpdateFloor={handleUpdateFloor}
          onDeleteFloor={handleDeleteFloor}
          onCreateRoom={handleCreateRoom}
          onUpdateRoom={handleUpdateRoom}
          onDeleteRoom={handleDeleteRoom}
          onClose={() => setIsLocationManagerOpen(false)}
        />
      )}

      {isUserManagerOpen && appData && (
        <UserManagerModal
          users={appData.users}
          currentUserId={currentUser.id}
          onCreateUser={handleCreateUser}
          onUpdateUser={handleUpdateUser}
          onDeleteUser={handleDeleteUser}
          onClose={() => setIsUserManagerOpen(false)}
        />
      )}

      {selectedRoomForTasks && appData && (
        <RoomTasksModal
          room={appData.rooms.find((r) => r.id === selectedRoomForTasks.id) || selectedRoomForTasks}
          floor={appData.floors.find((f) => f.id === selectedRoomForTasks.floorId)}
          boxesInRoom={appData.boxes.filter(
            (b) => b.currentRoomId === selectedRoomForTasks.id && b.status === 'IN_OLD_HOUSE'
          )}
          userRole={currentUser.role}
          onToggleReadiness={handleToggleRoomReadiness}
          onAddTask={handleAddTask}
          onToggleTask={handleToggleTask}
          onDeleteTask={handleDeleteTask}
          onSelectBox={(box) => {
            setSelectedRoomForTasks(null);
            setSelectedBox(box);
          }}
          onClose={() => setSelectedRoomForTasks(null)}
        />
      )}

      {isMeterReadingsOpen && appData && (
        <MeterReadingsModal
          meterReadings={appData.meterReadings || []}
          onSaveReading={handleSaveMeterReading}
          onClose={() => setIsMeterReadingsOpen(false)}
        />
      )}

      {isMoveDayTimelineOpen && appData && (
        <MoveDayTimelineModal
          tasks={appData.moveDayTasks || []}
          userRole={currentUser.role}
          onToggleTask={handleToggleMoveDayTask}
          onAddTask={handleAddMoveDayTask}
          onDeleteTask={handleDeleteMoveDayTask}
          onClose={() => setIsMoveDayTimelineOpen(false)}
        />
      )}
    </div>
  );
}
