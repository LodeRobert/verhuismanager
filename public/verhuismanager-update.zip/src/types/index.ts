export type UserRole = 'admin' | 'guest';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  createdAt: string;
}

export type HouseType = 'OLD' | 'NEW';

export type TaskCategory = 'INPAKKEN' | 'POETSEN' | 'KLUSSEN' | 'OVERIG';

export interface RoomTask {
  id: string;
  text: string;
  completed: boolean;
  category: TaskCategory;
  createdAt: string;
}

export interface Floor {
  id: string;
  name: string;
  houseType: HouseType;
  orderIndex: number;
}

export interface Room {
  id: string;
  floorId: string;
  name: string;
  houseType: HouseType;
  isDefaultFallback?: boolean; // Typically the Garage in the new house
  isReadyForMove?: boolean; // Big checkmark: room is completely packed & clean, ready for move day
  tasks?: RoomTask[];
  orderIndex: number;
}

export type BoxStatus = 'IN_OLD_HOUSE' | 'IN_TRANSIT' | 'MOVED';

export interface Box {
  id: string; // e.g. "BOX-001"
  boxNumber: number;
  title: string;
  items: string[];
  fragile: boolean;
  targetRoomId: string; // Destination room in new house
  currentRoomId: string; // Current physical location (e.g. room in old house or garage/room in new house)
  status: BoxStatus;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface DymoSettings {
  widthMm: number;
  heightMm: number;
  name: string;
  fontSizeScale: number;
  showContents: boolean;
  showFloor: boolean;
}

export type MeterType = 'WATER' | 'ELECTRICITY_DAY' | 'ELECTRICITY_NIGHT' | 'GAS' | 'SOLAR';

export interface MeterReading {
  id: string;
  houseType: HouseType;
  type: MeterType;
  name: string;
  reading: string;
  unit: string;
  date: string;
  notes?: string;
}

export interface MoveDayTask {
  id: string;
  time: string;
  title: string;
  description?: string;
  completed: boolean;
  assignedTo?: string;
}

export interface AppState {
  users: User[];
  floors: Floor[];
  rooms: Room[];
  boxes: Box[];
  settings: DymoSettings;
  meterReadings: MeterReading[];
  moveDayTasks: MoveDayTask[];
  isFirstRun: boolean;
}
