import React from 'react';
import {
  Package,
  Camera,
  Layers,
  Users,
  Printer,
  LogOut,
  Shield,
  User as UserIcon,
  Home,
  Plus,
  Gauge,
  Clock,
  Menu,
} from 'lucide-react';
import { User, UserRole } from '../types/index.ts';

interface NavbarProps {
  currentUser: User;
  activeTab: 'dashboard' | 'rooms';
  setActiveTab: (tab: 'dashboard' | 'rooms') => void;
  onOpenScanner: () => void;
  onOpenPrintModal: () => void;
  onOpenLocationManager: () => void;
  onOpenUserManager: () => void;
  onOpenMeterReadings: () => void;
  onOpenMoveDayTimeline: () => void;
  onAddNewBox: () => void;
  onLogout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  activeTab,
  setActiveTab,
  onOpenScanner,
  onOpenPrintModal,
  onOpenLocationManager,
  onOpenUserManager,
  onOpenMeterReadings,
  onOpenMoveDayTimeline,
  onAddNewBox,
  onLogout,
}) => {
  const isAdmin = currentUser.role === 'admin';

  return (
    <>
      {/* DESKTOP / TABLET TOP BAR */}
      <header className="no-print sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4 md:gap-8">
          {/* Zone 1: Brand wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-600/20">
              <Package className="w-5 h-5" />
            </div>
            <div className="flex items-center gap-2">
              <a
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  setActiveTab('dashboard');
                }}
                className="text-lg font-extrabold tracking-tight text-slate-900 dark:text-white whitespace-nowrap"
              >
                VerhuisManager
              </a>
              <span className="text-[10px] font-black uppercase tracking-wider bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700 px-1.5 py-0.5 rounded-md">
                v2.1
              </span>
            </div>
          </div>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden md:flex items-center gap-5 text-xs sm:text-sm font-semibold text-slate-600 dark:text-slate-300">
            <button
              type="button"
              onClick={() => setActiveTab('dashboard')}
              className={`whitespace-nowrap transition-colors cursor-pointer ${
                activeTab === 'dashboard'
                  ? 'text-blue-600 dark:text-blue-400 font-bold border-b-2 border-blue-600 dark:border-blue-400 py-1'
                  : 'hover:text-slate-900 dark:hover:text-white py-1'
              }`}
            >
              Totaaloverzicht
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('rooms')}
              className={`whitespace-nowrap transition-colors cursor-pointer ${
                activeTab === 'rooms'
                  ? 'text-blue-600 dark:text-blue-400 font-bold border-b-2 border-blue-600 dark:border-blue-400 py-1'
                  : 'hover:text-slate-900 dark:hover:text-white py-1'
              }`}
            >
              Kamerbeheer
            </button>

            <button
              type="button"
              onClick={onOpenMeterReadings}
              className="hover:text-slate-900 dark:hover:text-white whitespace-nowrap transition-colors cursor-pointer py-1 flex items-center gap-1.5"
            >
              <Gauge className="w-4 h-4 text-amber-500" />
              <span>Meterstanden</span>
            </button>

            <button
              type="button"
              onClick={onOpenMoveDayTimeline}
              className="hover:text-slate-900 dark:hover:text-white whitespace-nowrap transition-colors cursor-pointer py-1 flex items-center gap-1.5"
            >
              <Clock className="w-4 h-4 text-emerald-500" />
              <span>Draaiboek</span>
            </button>

            <button
              type="button"
              onClick={onOpenPrintModal}
              className="hover:text-slate-900 dark:hover:text-white whitespace-nowrap transition-colors cursor-pointer py-1"
            >
              Dymo Labels
            </button>

            {isAdmin && (
              <>
                <button
                  type="button"
                  onClick={onOpenLocationManager}
                  className="hover:text-slate-900 dark:hover:text-white whitespace-nowrap transition-colors cursor-pointer py-1"
                >
                  Locaties
                </button>
                <button
                  type="button"
                  onClick={onOpenUserManager}
                  className="hover:text-slate-900 dark:hover:text-white whitespace-nowrap transition-colors cursor-pointer py-1"
                >
                  Gebruikers
                </button>
              </>
            )}
          </nav>

          {/* Zone 3: Primary Action & Profile */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Quick action buttons for mobile top bar */}
            <div className="flex md:hidden items-center gap-1 mr-1">
              <button
                type="button"
                onClick={onOpenPrintModal}
                className="w-8 h-8 rounded-lg text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center cursor-pointer"
                title="Dymo Labels"
              >
                <Printer className="w-4 h-4" />
              </button>
              {isAdmin && (
                <button
                  type="button"
                  onClick={onOpenLocationManager}
                  className="w-8 h-8 rounded-lg text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center cursor-pointer"
                  title="Locatiebeheer"
                >
                  <Home className="w-4 h-4" />
                </button>
              )}
            </div>

            <button
              type="button"
              onClick={onOpenScanner}
              className="px-3 sm:px-3.5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-xl shadow-md shadow-blue-600/20 flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap min-h-[40px]"
            >
              <Camera className="w-4 h-4" />
              <span className="hidden sm:inline">Doos Scannen</span>
              <span className="sm:hidden">Scan</span>
            </button>

            {/* User Chip & Logout */}
            <div className="flex items-center gap-2 pl-2 border-l border-slate-200 dark:border-slate-800">
              <div className="hidden lg:flex flex-col text-right">
                <span className="text-xs font-bold text-slate-900 dark:text-white truncate max-w-[120px]">
                  {currentUser.name}
                </span>
                <span className="text-[10px] text-slate-400 font-medium capitalize">
                  {isAdmin ? 'Beheerder (Admin)' : 'Verhuishulp (Gast)'}
                </span>
              </div>

              <button
                type="button"
                onClick={onLogout}
                className="w-9 h-9 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center text-slate-400 hover:text-red-500 transition-colors cursor-pointer"
                title="Uitloggen"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* MOBILE BOTTOM NAVIGATION BAR (5 ergonomic touch buttons) */}
      <div className="md:hidden no-print fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 pb-safe">
        <div className="grid grid-cols-5 items-center h-16 px-1">
          {/* 1. Dashboard / Dozen */}
          <button
            type="button"
            onClick={() => setActiveTab('dashboard')}
            className={`flex flex-col items-center justify-center min-h-[44px] cursor-pointer ${
              activeTab === 'dashboard' ? 'text-blue-600 dark:text-blue-400 font-bold' : 'text-slate-500 dark:text-slate-400'
            }`}
          >
            <Package className="w-5 h-5" />
            <span className="text-[10px] tracking-tight mt-1">Dozen</span>
          </button>

          {/* 2. Kamers & Werkpunten */}
          <button
            type="button"
            onClick={() => setActiveTab('rooms')}
            className={`flex flex-col items-center justify-center min-h-[44px] cursor-pointer ${
              activeTab === 'rooms' ? 'text-blue-600 dark:text-blue-400 font-bold' : 'text-slate-500 dark:text-slate-400'
            }`}
          >
            <Layers className="w-5 h-5" />
            <span className="text-[10px] tracking-tight mt-1">Kamers</span>
          </button>

          {/* 3. Central Scanner */}
          <button
            type="button"
            onClick={onOpenScanner}
            className="flex flex-col items-center justify-center min-h-[44px] text-blue-600 dark:text-blue-400 cursor-pointer"
          >
            <div className="w-10 h-10 -mt-4 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-lg shadow-blue-600/30">
              <Camera className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-bold tracking-tight mt-0.5">Scannen</span>
          </button>

          {/* 4. Meterstanden */}
          <button
            type="button"
            onClick={onOpenMeterReadings}
            className="flex flex-col items-center justify-center min-h-[44px] text-slate-500 dark:text-slate-400 cursor-pointer hover:text-amber-600"
          >
            <Gauge className="w-5 h-5" />
            <span className="text-[10px] tracking-tight mt-1">Meters</span>
          </button>

          {/* 5. Draaiboek */}
          <button
            type="button"
            onClick={onOpenMoveDayTimeline}
            className="flex flex-col items-center justify-center min-h-[44px] text-slate-500 dark:text-slate-400 cursor-pointer hover:text-emerald-600"
          >
            <Clock className="w-5 h-5" />
            <span className="text-[10px] tracking-tight mt-1">Draaiboek</span>
          </button>
        </div>
      </div>
    </>
  );
};
