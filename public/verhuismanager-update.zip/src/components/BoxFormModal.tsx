import React, { useState } from 'react';
import { X, Plus, Trash2, AlertTriangle, Package, Check } from 'lucide-react';
import { Box, Room, Floor } from '../types/index.ts';

interface BoxFormModalProps {
  initialBox?: Box | null;
  rooms: Room[];
  floors: Floor[];
  existingBoxesCount: number;
  onSave: (boxData: Partial<Box>) => Promise<void>;
  onClose: () => void;
}

export const BoxFormModal: React.FC<BoxFormModalProps> = ({
  initialBox,
  rooms,
  floors,
  existingBoxesCount,
  onSave,
  onClose,
}) => {
  const isEditing = Boolean(initialBox);

  const [boxNumber, setBoxNumber] = useState<number>(
    initialBox ? initialBox.boxNumber : existingBoxesCount + 1
  );
  const [title, setTitle] = useState(initialBox ? initialBox.title : '');
  const [fragile, setFragile] = useState(initialBox ? initialBox.fragile : false);
  const [targetRoomId, setTargetRoomId] = useState<string>(
    initialBox ? initialBox.targetRoomId : rooms[0]?.id || ''
  );
  const [currentRoomId, setCurrentRoomId] = useState<string>(
    initialBox ? initialBox.currentRoomId : rooms[0]?.id || ''
  );
  const [notes, setNotes] = useState(initialBox ? initialBox.notes || '' : '');
  const [items, setItems] = useState<string[]>(initialBox ? [...initialBox.items] : []);
  const [newItemText, setNewItemText] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleAddItem = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!newItemText.trim()) return;
    setItems([...items, newItemText.trim()]);
    setNewItemText('');
  };

  const handleRemoveItem = (index: number) => {
    setItems(items.filter((_, idx) => idx !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Vul een titel of omschrijving in voor de doos.');
      return;
    }
    if (!targetRoomId) {
      setError('Selecteer een doelruimte in het nieuwe huis.');
      return;
    }

    setLoading(true);
    setError(null);
    try {
      await onSave({
        boxNumber,
        title: title.trim(),
        fragile,
        targetRoomId,
        currentRoomId: currentRoomId || targetRoomId,
        items,
        notes: notes.trim(),
      });
      onClose();
    } catch (err: unknown) {
      if (err instanceof Error) setError(err.message);
      else setError('Fout bij opslaan van de doos.');
    } finally {
      setLoading(false);
    }
  };

  // Group rooms by floor
  const getRoomsForFloor = (floorId: string) => rooms.filter((r) => r.floorId === floorId);

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 no-print overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-lg w-full shadow-2xl overflow-hidden my-auto flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-md shadow-blue-600/20">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {isEditing ? `Doos #${initialBox?.boxNumber} Bewerken` : 'Nieuwe Verhuisdoos Toevoegen'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Vul details, inhoud en doelruimte in voor het Dymo-label
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center text-slate-500 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-4 overflow-y-auto max-h-[75vh]">
          {error && (
            <div className="p-3 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 rounded-xl text-xs">
              {error}
            </div>
          )}

          <div className="grid grid-cols-3 gap-3">
            <div className="col-span-1">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Doosnummer:
              </label>
              <input
                type="number"
                min={1}
                required
                value={boxNumber}
                onChange={(e) => setBoxNumber(Number(e.target.value))}
                className="w-full px-3 py-2 text-sm font-mono font-bold bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
              />
            </div>

            <div className="col-span-2">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Titel / Korte Omschrijving:
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="bijv. Keukenpannen & Bestek"
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Fragile Switch */}
          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div
                className={`w-9 h-9 rounded-lg flex items-center justify-center transition-colors ${
                  fragile ? 'bg-red-100 text-red-600 dark:bg-red-950/70 dark:text-red-400' : 'bg-slate-200 text-slate-500 dark:bg-slate-700'
                }`}
              >
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs font-bold text-slate-900 dark:text-white">Breekbare Inhoud?</div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400">
                  Toont grote waarschuwing op het Dymo-label
                </div>
              </div>
            </div>

            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={fragile}
                onChange={(e) => setFragile(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-red-600"></div>
            </label>
          </div>

          {/* Target Room */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Doelruimte in Nieuwe Huis (Waar moet deze doos naartoe?):
            </label>
            <select
              value={targetRoomId}
              onChange={(e) => setTargetRoomId(e.target.value)}
              className="w-full px-3 py-2.5 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white font-medium"
            >
              {floors.map((floor) => {
                const floorRooms = getRoomsForFloor(floor.id);
                if (floorRooms.length === 0) return null;
                return (
                  <optgroup key={floor.id} label={`Verdieping: ${floor.name}`}>
                    {floorRooms.map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.name} {r.isDefaultFallback ? '(Standaard Buffer)' : ''}
                      </option>
                    ))}
                  </optgroup>
                );
              })}
            </select>
          </div>

          {/* Inhoud (Items toevoegen) */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Inhoud van de doos (Lijst van items):
            </label>
            <div className="flex gap-2 mb-2">
              <input
                type="text"
                value={newItemText}
                onChange={(e) => setNewItemText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddItem();
                  }
                }}
                placeholder="Typ item en druk op Enter (bijv. Koffiezetapparaat)"
                className="flex-1 px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white placeholder-slate-400"
              />
              <button
                type="button"
                onClick={() => handleAddItem()}
                className="px-3 py-2 bg-slate-800 dark:bg-slate-700 hover:bg-slate-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Toevoegen</span>
              </button>
            </div>

            {items.length > 0 ? (
              <div className="flex flex-wrap gap-1.5 p-2 bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/60 rounded-xl max-h-36 overflow-y-auto">
                {items.map((it, idx) => (
                  <span
                    key={idx}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-700 rounded-lg shadow-sm"
                  >
                    <span>{it}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveItem(idx)}
                      className="text-slate-400 hover:text-red-500 cursor-pointer"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>
            ) : (
              <p className="text-[11px] text-slate-400 italic">
                Nog geen items toegevoegd. U kunt ook later items aanvullen.
              </p>
            )}
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Extra notities of instructies:
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="bijv. Voorzichtig tillen, eerste dag openmaken"
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder-slate-400"
            />
          </div>

          {/* Submit buttons */}
          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl cursor-pointer"
            >
              Annuleren
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-lg shadow-blue-600/20 flex items-center gap-2 cursor-pointer min-h-[44px]"
            >
              <Check className="w-4 h-4" />
              <span>{loading ? 'Bezig met opslaan...' : isEditing ? 'Wijzigingen Opslaan' : 'Doos Aanmaken'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
