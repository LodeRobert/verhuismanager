import React, { useState } from 'react';
import {
  X,
  CheckCircle2,
  Circle,
  Plus,
  Trash2,
  CheckSquare,
  Sparkles,
  Package,
  Wrench,
  Brush,
  Tag,
  ShieldCheck,
  AlertCircle,
  ArrowRight,
} from 'lucide-react';
import { Room, Floor, Box, RoomTask, TaskCategory, UserRole } from '../types/index.ts';

interface RoomTasksModalProps {
  room: Room;
  floor?: Floor;
  boxesInRoom: Box[];
  userRole: UserRole;
  onToggleReadiness: (roomId: string, isReady: boolean) => Promise<void>;
  onAddTask: (roomId: string, task: { text: string; category: TaskCategory }) => Promise<void>;
  onToggleTask: (roomId: string, taskId: string, completed: boolean) => Promise<void>;
  onDeleteTask: (roomId: string, taskId: string) => Promise<void>;
  onSelectBox?: (box: Box) => void;
  onClose: () => void;
}

export const RoomTasksModal: React.FC<RoomTasksModalProps> = ({
  room,
  floor,
  boxesInRoom,
  userRole,
  onToggleReadiness,
  onAddTask,
  onToggleTask,
  onDeleteTask,
  onSelectBox,
  onClose,
}) => {
  const isOldHouse = room.houseType === 'OLD';
  const tasks = room.tasks || [];
  const completedTasks = tasks.filter((t) => t.completed).length;
  const progressPercent = tasks.length > 0 ? Math.round((completedTasks / tasks.length) * 100) : 0;

  const [newTaskText, setNewTaskText] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<TaskCategory>('INPAKKEN');
  const [loading, setLoading] = useState(false);

  const handleToggleRoomReady = async () => {
    setLoading(true);
    try {
      await onToggleReadiness(room.id, !room.isReadyForMove);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateTask = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!newTaskText.trim()) return;
    setLoading(true);
    try {
      await onAddTask(room.id, { text: newTaskText.trim(), category: selectedCategory });
      setNewTaskText('');
    } finally {
      setLoading(false);
    }
  };

  const getCategoryBadge = (cat: TaskCategory) => {
    switch (cat) {
      case 'INPAKKEN':
        return (
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 flex items-center gap-1">
            <Package className="w-2.5 h-2.5" /> Inpakken
          </span>
        );
      case 'POETSEN':
        return (
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 flex items-center gap-1">
            <Brush className="w-2.5 h-2.5" /> Poetsen
          </span>
        );
      case 'KLUSSEN':
        return (
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 flex items-center gap-1">
            <Wrench className="w-2.5 h-2.5" /> Klussen
          </span>
        );
      default:
        return (
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 flex items-center gap-1">
            <Tag className="w-2.5 h-2.5" /> Overig
          </span>
        );
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5 no-print overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-2xl w-full shadow-2xl overflow-hidden my-auto flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                {isOldHouse ? '🏠 Oud Huis (Vertrek)' : '🏡 Nieuw Huis (Bestemming)'}
              </span>
              <span className="text-slate-300 dark:text-slate-700">•</span>
              <span className="text-xs text-slate-500 dark:text-slate-400">
                Verdieping: {floor?.name || 'Onbekend'}
              </span>
            </div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white mt-0.5">
              {room.name} — Werkpunten & Status
            </h2>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center text-slate-500 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 space-y-5 overflow-y-auto max-h-[75vh]">
          {/* PROMINENT "KLAAR VOOR VERHUIS" VINKJE (Vooral essentieel voor Oud Huis) */}
          <div
            onClick={handleToggleRoomReady}
            className={`p-4 rounded-2xl border-2 transition-all cursor-pointer flex items-center justify-between shadow-xs ${
              room.isReadyForMove
                ? 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-500 text-emerald-950 dark:text-emerald-100'
                : 'bg-slate-50 dark:bg-slate-800/40 border-slate-300 dark:border-slate-700 hover:border-emerald-400 text-slate-700 dark:text-slate-300'
            }`}
          >
            <div className="flex items-center gap-3.5">
              <div
                className={`w-12 h-12 rounded-xl flex items-center justify-center shadow-md transition-transform active:scale-95 ${
                  room.isReadyForMove
                    ? 'bg-emerald-600 text-white shadow-emerald-600/30'
                    : 'bg-slate-200 dark:bg-slate-700 text-slate-400'
                }`}
              >
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-sm sm:text-base font-extrabold">
                    {room.isReadyForMove
                      ? '✓ Deze kamer is 100% KLAAR voor de verhuis!'
                      : 'Kamer gereed voor verhuis?'}
                  </span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  {room.isReadyForMove
                    ? 'Alles is ingepakt, gepoetst en klaar om direct in te laden zonder extra werk.'
                    : 'Klik hier zodra alles in deze kamer is ingepakt en schoongemaakt.'}
                </p>
              </div>
            </div>

            <div className="shrink-0 hidden sm:block">
              <span
                className={`px-3 py-1.5 rounded-xl text-xs font-black uppercase tracking-wider ${
                  room.isReadyForMove
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                }`}
              >
                {room.isReadyForMove ? 'KLAAR' : 'NIET KLAAR'}
              </span>
            </div>
          </div>

          {/* BOXEN DIE NOG IN DEZE KAMER STAAN (Alleen relevant als er dozen fysiek staan) */}
          {boxesInRoom.length > 0 && (
            <div className="p-3.5 bg-blue-50/70 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/60 rounded-xl space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-blue-950 dark:text-blue-200">
                <span className="flex items-center gap-1.5">
                  <Package className="w-4 h-4 text-blue-600" />
                  <span>Dozen die momenteel in deze kamer staan ({boxesInRoom.length}):</span>
                </span>
              </div>
              <div className="flex flex-wrap gap-2 pt-1">
                {boxesInRoom.map((b) => (
                  <button
                    key={b.id}
                    onClick={() => {
                      if (onSelectBox) {
                        onClose();
                        onSelectBox(b);
                      }
                    }}
                    className="px-2.5 py-1 text-xs bg-white dark:bg-slate-900 border border-blue-200 dark:border-blue-800 hover:border-blue-500 rounded-lg text-slate-800 dark:text-slate-200 font-semibold flex items-center gap-1.5 cursor-pointer shadow-2xs"
                  >
                    <span className="font-mono text-blue-600">#{b.boxNumber}</span>
                    <span className="truncate max-w-[140px]">{b.title}</span>
                    <ArrowRight className="w-3 h-3 text-slate-400" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* WERKPUNTEN CHECKLIST */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <CheckSquare className="w-4 h-4 text-blue-600" />
                  <span>Werkpunten Checklist ({completedTasks}/{tasks.length})</span>
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Taken om in te pakken, op te kuisen of te klussen in deze ruimte
                </p>
              </div>

              {tasks.length > 0 && (
                <div className="text-xs font-mono font-bold text-slate-700 dark:text-slate-300 tabular-nums">
                  {progressPercent}% voltooid
                </div>
              )}
            </div>

            {/* Progress bar */}
            {tasks.length > 0 && (
              <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all duration-300 rounded-full ${
                    progressPercent === 100 ? 'bg-emerald-500' : 'bg-blue-600'
                  }`}
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            )}

            {/* Snel Nieuw Werkpunt Toevoegen */}
            <form onSubmit={handleCreateTask} className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2.5">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newTaskText}
                  onChange={(e) => setNewTaskText(e.target.value)}
                  placeholder="Nieuw werkpunt (bv. Diepvries ontdooien, muur plamuren...)"
                  className="flex-1 px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <button
                  type="submit"
                  disabled={loading || !newTaskText.trim()}
                  className="px-3 py-2 bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white text-xs font-bold rounded-lg flex items-center gap-1 cursor-pointer min-h-[38px]"
                >
                  <Plus className="w-4 h-4" />
                  <span className="hidden sm:inline">Toevoegen</span>
                </button>
              </div>

              {/* Category selector buttons */}
              <div className="flex items-center gap-2 flex-wrap text-xs">
                <span className="text-[11px] font-semibold text-slate-500">Categorie:</span>
                {(['INPAKKEN', 'POETSEN', 'KLUSSEN', 'OVERIG'] as TaskCategory[]).map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-2 py-0.5 text-xs rounded-full border transition-all cursor-pointer ${
                      selectedCategory === cat
                        ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold border-transparent'
                        : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:border-slate-400'
                    }`}
                  >
                    {cat === 'INPAKKEN' && '📦 Inpakken'}
                    {cat === 'POETSEN' && '🧹 Poetsen'}
                    {cat === 'KLUSSEN' && '🔧 Klussen'}
                    {cat === 'OVERIG' && '📌 Overig'}
                  </button>
                ))}
              </div>
            </form>

            {/* Takenlijst */}
            <div className="space-y-1.5 max-h-64 overflow-y-auto">
              {tasks.length > 0 ? (
                tasks.map((task) => (
                  <div
                    key={task.id}
                    className={`p-2.5 rounded-xl border flex items-center justify-between gap-3 transition-colors ${
                      task.completed
                        ? 'bg-slate-50/80 dark:bg-slate-900/40 border-slate-200 dark:border-slate-800/80 text-slate-400'
                        : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 shadow-2xs'
                    }`}
                  >
                    <div
                      onClick={() => onToggleTask(room.id, task.id, !task.completed)}
                      className="flex items-center gap-2.5 flex-1 cursor-pointer select-none"
                    >
                      <button
                        type="button"
                        className={`w-5 h-5 rounded flex items-center justify-center transition-colors ${
                          task.completed
                            ? 'text-emerald-500 dark:text-emerald-400'
                            : 'text-slate-400 hover:text-slate-600'
                        }`}
                      >
                        {task.completed ? <CheckCircle2 className="w-5 h-5" /> : <Circle className="w-5 h-5" />}
                      </button>

                      <div className="flex-1">
                        <span
                          className={`text-xs ${
                            task.completed ? 'line-through text-slate-400 dark:text-slate-500' : 'font-medium'
                          }`}
                        >
                          {task.text}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {getCategoryBadge(task.category)}
                      <button
                        type="button"
                        onClick={() => onDeleteTask(room.id, task.id)}
                        className="p-1 text-slate-400 hover:text-red-500 rounded cursor-pointer"
                        title="Verwijder werkpunt"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-4 text-center text-xs text-slate-400 italic bg-slate-50/50 dark:bg-slate-800/20 rounded-xl border border-dashed border-slate-200 dark:border-slate-800">
                  Nog geen werkpunten voor deze ruimte. Voeg hierboven taken toe zoals inpakken of poetsen.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 dark:bg-slate-900/80 border-t border-slate-200 dark:border-slate-800 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 text-slate-800 dark:text-slate-200 rounded-xl cursor-pointer"
          >
            Klaar
          </button>
        </div>
      </div>
    </div>
  );
};
